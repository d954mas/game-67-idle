---
id: T0435
title: Separate current work from ready backlog in agent context
status: done
project: P001
epic: E001
priority: P1
tags: [taskboard, context, clarity]
created: 2026-07-14
updated: 2026-07-14
quality: {"checks":[{"id":"QTECH_001","outcome":"pass","evidence":"QTECH_001=TDD regressions and full Taskboard suite 74/74; single-store, aggregate, CLI/API, profiler and body-free row budget verified"}]}
---

## What

Make Taskboard context describe actual selected work instead of counting every
refined backlog card as current. Preserve a bounded, body-free ready queue for
the next routing decision.

## Done when

- [x] `currentWork` contains only `todo`, `doing`, and `review` tasks.
- [x] Backlog is returned separately as at most three ranked `readyQueue` rows
      without exceeding the total context row limit.
- [x] Single-store, aggregate-store, text CLI, HTTP API, and read profiling use
      the same contract without task bodies.
- [x] Documentation and focused/full Taskboard tests pass.

## Open questions

- None; the lead approved the `currentWork` versus backlog split on 2026-07-14.

## Log

- 2026-07-14: Started with TDD. Scope is reporting/context semantics only;
  statuses, task files, browser columns, and backlog contents stay unchanged.
- 2026-07-14: RED proved v1 mixed backlog/current output was wrong. The v2
  contract now separates counts and rows, caps the combined default payload at
  five rows, and emits an explicit text notice when backlog is omitted by that
  budget.
- 2026-07-14: Quality evidence: QTECH_001 pass — focused RED/GREEN regressions,
  full `node --test ai_studio/taskboard/tests/taskboard.test.mjs` 74/74,
  `validate --json` ok, and `git diff --check` clean.
- 2026-07-14: Quality: QTECH_001=pass; evidence: QTECH_001=TDD regressions and full Taskboard suite 74/74; single-store, aggregate, CLI/API, profiler and body-free row budget verified
