---
id: T0382
title: Build isolated deterministic Items and Balance Lua sandbox
status: done
project: P001
epic: E016
priority: P0
tags: [items, balance, lua, sandbox]
created: 2026-07-10
updated: 2026-07-15
quality: {"checks":[{"id":"QTECH_001","outcome":"pass","evidence":"9 sandbox tests; features domain pass in 6.2s; CI 29370189573 passed Ubuntu and Windows; independent security re-review clear"}]}
---

## What

Implement the deterministic module loader and fresh-process sandbox against the
ratified Items declaration contract and representative backend benchmark.

## Done when

- [x] A small representative declaration workload selects and pins the simplest
      Lua backend/version that satisfies the sandbox hooks; no separate backend
      benchmark project is required.

- [x] Approved modules resolve in deterministic order with cycle diagnostics;
      author code cannot use filesystem, network, shell, environment, time,
      random, dynamic loading, bytecode, debug, FFI, or unrestricted JIT.
- [x] Unordered iteration and mutable declaration state are unavailable; inputs
      are frozen/deep-copied and repeated full runs match exactly.
- [x] V1 always evaluates in a fresh isolated process with CPU/memory/instruction/
      recursion/output limits; timeout/OOM cannot corrupt the host.
- [x] Exported formulas use the approved deterministic math surface; raw libm
      exponentiation is excluded from the first proof.
- [x] Errors carry stable code, game-relative file, line/column, and field path.
- [x] Currency/fixed-sword/levelled-sword fixtures match on Windows/Linux and
      across repeated runs with the selected backend/version fingerprint.

## Open questions

- Admit incremental evaluation only through a later purity/full-parity proof.

## Log

- 2026-07-14: Absorbed the decision-relevant part of T0363. Large/full-pipeline
  measurement remains the final T0380 gate.

- 2026-07-10: Tightened after red-team findings on `pairs`, mutable closures,
  libm differences, LuaJIT hooks, and stale incremental results.
- 2026-07-14: Selected as the next risk-first task after full active-card grooming; it is the first dependency of the E016 authoring vertical.
- 2026-07-14: Started backend selection and deterministic sandbox implementation. Scope: fresh-process evaluator/module loader plus representative Items fixtures; Snapshot/runtime export remain T0383/T0365.
- 2026-07-15: Pinned `lupa==2.8` and `lupa.lua54`. A 5 x 100 fresh-runtime
  representative comparison measured median 0.053 ms for Lua 5.4 and 0.060 ms
  for LuaJIT 2.1 with JIT disabled. Both supplied memory limits, instruction
  hooks, and text-only loading; Lua 5.4 avoids a JIT policy and Lua 5.1 integer
  compatibility layer. The temporary benchmark script was not retained.
- 2026-07-15: Independent security review found marker-spoofing and inherited
  string-library access. Both were fixed with an unforgeable typed callback and
  a closed string surface; targeted re-review found no residual blocker.
- 2026-07-15: Test process overhead reduced without weakening fresh-process
  proof: Lua suite fell from about 6.9 s to 4.5 s and the full features domain
  from 9.1 s to 6.2 s on Windows.
- 2026-07-15: Quality: QTECH_001=pass; evidence: 9 sandbox tests, feature
  contracts, `studio verify --domain features`, and Studio CI run 29370189573
  passed on Ubuntu and Windows.
- 2026-07-15: Completed deterministic Lua sandbox, backend pin, parity fixture, limits, typed diagnostics, and security hardening.
- 2026-07-15: Quality: QTECH_001=pass; evidence: 9 sandbox tests; features domain pass in 6.2s; CI 29370189573 passed Ubuntu and Windows; independent security re-review clear
