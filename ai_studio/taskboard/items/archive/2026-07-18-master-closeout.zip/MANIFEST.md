# Sealed Taskboard history

Batch: 2026-07-18-master-closeout
Tasks: 21

## Tasks

- T0316 | E016 | AI Studio: Items Workbench поверх Lua Snapshot
- T0317 | E010 | AI Studio: арт-гейт против битых вырезок - авто-проверка альфы/фона/обрезки до попадания ассета в игру
- T0323 | E009 | Add packaged-web browser load smoke to the template release flow
- T0326 | E010 | style lock: canvas style group + style_lock.json + acceptance gate in asset pipeline
- T0365 | E016 | Benchmark and build the compact typed Items runtime package
- T0366 | E016 | Create focused Items CLI and agent skill routing
- T0380 | E016 | Benchmark complete Items build and agent loop
- T0381 | E016 | Build phased Items registration refs and release compatibility receipt
- T0383 | E016 | Build typed Items Snapshot provenance and focused dependency queries
- T0386 | E016 | Cut over Items JSON and schema to single-source modular Lua
- T0388 | E019 | Build atomic Items payment acquisition and upgrade verbs
- T0390 | E019 | Build dynamic Items containers and nested runtime entries
- T0391 | E019 | Extend Game State generator for nested Items container state
- T0392 | E019 | Migrate legacy Items state references and event consumers
- T0436 | E020 | Fix evidence gaps found by workflow profiling
- T0437 | E016 | Harden Items Workbench writes and catalog-scoped async state
- T0438 | E016 | Close Items authoring package and writer integrity gaps
- T0439 | E016 | Bound Items Workbench I/O and remove obsolete proof coupling
- T0440 | E009 | runtime_automation: DevApiClient byte-at-a-time socket reads stall large capture responses past the engine 2s send timeout (connection drop)
- T0441 | E009 | template node tools: probe studio root depth like cmake (private games/<id> crash)
- T0442 | E009 | template local-mock web shell never hides its loading overlay (game runs fine underneath)
