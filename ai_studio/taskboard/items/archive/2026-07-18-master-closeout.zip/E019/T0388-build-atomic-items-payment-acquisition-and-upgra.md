---
id: T0388
title: Build atomic Items payment acquisition and upgrade verbs
status: done
project: P001
epic: E019
priority: P1
tags: [items, runtime, state, transaction]
created: 2026-07-10
updated: 2026-07-17
quality: {"checks":[{"id":"QTECH_001","outcome":"pass","evidence":"QTECH_001=node ai_studio/studio.mjs verify --full passed 10 domains; GitHub Actions run 29555891382 passed Ubuntu and Windows"}]}
---

## What

Provide generic all-or-nothing runtime verbs for normalized composite payment,
item acquisition, and unique-instance level upgrades. Game policy decides when
an action is offered; Items owns catalog/state/storage invariants and commit
atomicity.

## Done when

- [x] `items_try_pay_cost` accepts one normalized resource-only cost plus an
      explicit ordered bounded runtime payment scope. Scope overflow or duplicate
      source containers assert as developer errors. It creates a deterministic plan,
      consumes containers in scope order and compatible stacks by ascending
      slot, preflights every source entry, then commits all or nothing.
- [x] Duplicate item requirements are canonicalized by export. Malformed,
      overflowing, or non-positive entries in the opaque normalized runtime cost
      are corrupt-catalog/developer assertions, never gameplay refusal. Runtime
      never performs a partial loop of public remove calls or hidden global search.
- [x] `items_try_acquire` pays `acquire.cost` and creates/adds the definition in
      an explicit destination container as one commit; failed capacity, policy,
      uniqueness, payment, or creation leaves state unchanged.
- [x] If destination is also a payment source, acquire applies the complete
      payment plan to projected state before planning placement/merge/ID
      allocation, then commits the combined plan once.
- [x] Missing `acquire.cost` makes generic acquisition unavailable; free
      acquisition is accepted only when authored explicitly as `items.free()`.
- [x] `items_try_upgrade_instance(item_entry_ref_t entry, target_level, payment, reason)`
      requires the next valid level in v1, obtains `cost_to_reach[target_level]`,
      pays, changes saved level, marks dirty, and emits one result atomically.
- [x] Explicit free and paid transitions are distinct; level 1/inapplicable is
      never treated as free. Persistent unlock state is outside this task.
- [x] Success/failure fixtures cover two explicit payer containers, duplicate
      resources, overflow, insufficient second resource, full/wrong-policy destination,
      wrong storage route, stale level, and injected commit failure with exact
      before/after state equality.
- [x] The implementation preserves existing reason-tag/event/audit contracts
      and exposes one bounded failure reason rather than intermediate events.
- [x] Invalid handles, missing required objects, duplicate/oversized payment
      scope, and malformed normalized cost assert. Only expected funds, capacity,
      policy, slot, unavailable acquisition, or pool exhaustion use bounded
      `can/try` refusal enums without partial mutation.

## Open questions

- Choose the smallest rollback-safe internal state mutation seam; do not expose
  a generic public transaction system unless the three verbs prove it necessary.
- Trading existing merchant stock remains Shop/game orchestration over atomic
  payment plus transfer; it is not catalog acquisition.

## Log

- 2026-07-14: Moved to E019. Atomic payment/acquisition is valuable runtime work
  after catalog costs and containers exist, not a Workbench blocker.

- 2026-07-10: Created from independent red-team/runtime reviews after composite
  costs exposed that sequential `can_afford`/`remove` calls cannot guarantee an
  atomic upgrade or acquisition.
- 2026-07-17: Started after T0390/T0391 closure because Taskboard ready queue ranks this P1 E019 task first; catalog costs and runtime containers are present. Work proceeds incrementally from payment planning tests.
- 2026-07-17: Implemented the first payment slice: bounded ordered scope,
  deterministic source/slot planning, exact no-mutation refusal, one commit,
  and a truthful typed `items.payment` summary event. Focused Items,
  progression, curve, and template-composition native tests pass; independent
  review findings on event semantics and slot-order evidence were addressed.
- 2026-07-17: Added atomic paid/explicit-free acquisition against projected
  post-payment state, including destination-source slot reuse, policy/capacity/
  storage/unavailable refusal equality, stable result events, and catalog-ID
  access in generated-C and runtime-package backends. Independent logic review
  accepted the slice; Items API/runtime, progression, and composition tests pass.
- 2026-07-17: Added generic catalog level-transition queries for generated-C
  and runtime packages plus atomic next-level unique-instance upgrades. Paid,
  free, stale, unavailable, quarantine, and persisted-level-boundary paths have
  exact-state/event fixtures; initial independent review findings were fixed.
- 2026-07-17: Closed the acceptance gaps with assert-trap developer-contract
  fixtures, free-acquire pool exhaustion, and a test-only precommit failure
  seam shared by pay/acquire/upgrade. Failure injection occurs after full
  preflight and before the first mutation; independent review accepted it.
- 2026-07-17: Completed atomic composite payment, paid/free acquisition, and next-level upgrade verbs with reviewed rollback/assert/event fixtures.
- 2026-07-17: Quality: QTECH_001=pass; evidence: QTECH_001=node ai_studio/studio.mjs verify --full passed 10 domains; GitHub Actions run 29555891382 passed Ubuntu and Windows
