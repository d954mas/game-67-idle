---
id: T0380
title: Benchmark complete Items build and agent loop
status: done
project: P001
epic: E016
priority: P2
tags: [balance, performance, benchmark]
created: 2026-07-10
updated: 2026-07-16
quality: {"checks":[{"id":"QTECH_001","outcome":"pass","evidence":"Reproducible before/after pipeline benchmark, full Items suites, changed gates, and Ubuntu/Windows CI run 29505520980"}]}
---

## What

After the evaluator, snapshot/export, and CLI exist, benchmark the production
end-to-end build and agent loop and use the results to optimize real bottlenecks.

## Done when

- [x] Representative cold, warm, no-op, one-edit, build, and runtime-bind flows
      expose their main wall-time and memory costs.
- [x] Agent scenarios report command/tool count, stdout/context bytes, reads,
      latency, and diagnostic quality for edit/validate/inspect/build loops.
- [x] Results explicitly ratify or reverse the provisional backend choice; the
      final pinned backend/version is recorded with the full-pipeline evidence.
- [x] Real bottlenecks are profiled before optimization; stress sizes and extra
      cross-platform matrices run only when they can change a release decision.
- [x] Proposed budgets remain advisory until explicitly accepted as gates.

## Open questions

## Log

- 2026-07-14: Absorbed final backend comparison from T0363 and removed the
  mandatory every-size/every-metric benchmark matrix.

- 2026-07-10: Resolves the dependency cycle found in final transcript audit:
  backend selection precedes production implementation; full-loop proof follows.
- 2026-07-16: Started after T0316 completed with green Ubuntu/Windows CI. Measure the finished Items production and agent loops before changing implementation; budgets remain advisory unless explicitly accepted.
- 2026-07-16: Slice 1 established the cross-platform measurement contract. One runner records subprocess-tree peak RSS, wall time, and exact stdout/stderr bytes on Windows and `/proc` platforms; pure tests require complete build/no-op/runtime-bind proof before ratifying pinned `lupa.lua54`/Lua 5.4/`lupa@2.8` plus compact blob v2. RED/green benchmark tests pass 3/3.
- 2026-07-16: Slice 2 measured the complete production and agent paths, then profiled the dominant fresh-worker startup before changing code. Reusing public `lupa.__version__` removed the heavy `importlib.metadata` graph from each worker: final advisory Windows samples improved cold validate 11.6%, warm validate 10.4%, no-op build 16.7%, safe Apply 13.4%, eight-command agent wall 12.9%, and peak process-tree RSS 10.2%. Production C bind is 500 ns median with 616 B steady/1,232 B transient. The evidence ratifies pinned Lupa/Lua 5.4 and compact blob v2; persistent caching and extra stress/Linux matrices are rejected as unjustified complexity, and budgets remain advisory.
- 2026-07-16: Closure verification: full Items Python and benchmark suites, native runtime-bind target, CMake ownership tests, and `studio verify --changed` passed locally. GitHub Studio verification run 29505520980 passed on both Ubuntu and Windows after replacing a too-short Linux RSS probe with an observable 50 ms test process. T0380 is complete.
- 2026-07-16: Quality: QTECH_001=pass; evidence: Reproducible before/after pipeline benchmark, full Items suites, changed gates, and Ubuntu/Windows CI run 29505520980
