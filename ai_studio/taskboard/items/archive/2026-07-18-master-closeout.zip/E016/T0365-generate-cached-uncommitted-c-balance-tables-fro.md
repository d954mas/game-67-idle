---
id: T0365
title: Benchmark and build the compact typed Items runtime package
status: done
project: P001
epic: E016
priority: P1
tags: [items, codegen, c, cache]
created: 2026-07-10
updated: 2026-07-16
quality: {"checks":[{"id":"QTECH_001","outcome":"pass","evidence":"QTECH_001=Linux and Windows Release artifacts match semantic checksum and blob decision; benchmark contract 3/3; Studio verify --changed passed features"}]}
---

## What

Compare generated C literal arrays with a compact normalized binary blob, then
turn a validated single-source Items Snapshot into the measured typed runtime
package without runtime Lua/JSON parsing.

## Done when

- [x] Export consumes only the normalized snapshot and performs no Lua/formula
      evaluation or semantic validation of its own.
- [x] A Windows/Linux benchmark compares C arrays with the compact blob for
      generation/link time, incremental rebuilds, package/transient/steady
      owned bytes, startup binding, and checked access. Process RSS and the
      representative full pipeline remain T0380. Blob plus small generated C
      API remains the default unless measurements disprove it.
- [x] The package follows the canonical E016 format: fixed-width little-endian
      flat core/field/level/cost sections, deduplicated strings, checked spans,
      stable item hashes, and separate schema-ABI/content fingerprints.
- [x] Binding through the public resource-blob path validates the complete
      header, fingerprints, bounds, indices, alignment, and content digest before
      atomically publishing one owned buffer; failure publishes nothing.
- [x] Generated typed definition refs are opaque and distinct from the future
      E019 runtime-entry refs; required absence/unbound use asserts, bounded
      `exists`/`try` alternatives are exposed, and hash/name collisions reject.
- [x] Value-only changes rebuild catalog data without relinking ABI-stable C;
      generated headers are write-if-different and no handwritten item IDs remain.
- [x] `items/catalog` placement remains a game-builder choice; pre-bind access
      fails, bind precedes state load, and publishing validates the catalog
      against the current Snapshot without a second authored manifest.
- [x] Default row/byte budgets fail early unless explicitly overridden; runtime
      contains no Lua/JSON parser, semantic evaluator, independently authored
      combat/economy table, or per-row allocation, and generated values match
      focused Snapshot inspection.

## Open questions

- Blob plus small typed C API is the production default unless the benchmark
  disproves it; C arrays remain the tiny-fixture/reference exporter.
- Exact pack placement is a game-builder decision and loading must use existing
  public resource boundaries by logical asset ID.

## Log

- 2026-07-14: Collapsed repeated wire/API clauses into seven measurable
  outcomes; detailed invariants remain canonical in E016 and the concept doc.

- 2026-07-10: Replaced the former separate Balance C-table plan after the lead
  selected one canonical Items Lua definition and one logical catalog package.
- 2026-07-10: Lead questioned generated-source duplication/size and runtime
  parsing. Re-scoped to benchmark naive C arrays against small typed generated
  APIs plus one compact flat blob; runtime binds validated spans, not configs.
- 2026-07-10: Runtime-package re-review initially suggested a dedicated pack;
  the lead later made physical placement a game-builder choice while retaining
  the logical asset, catalog-before-state gate, wire/fingerprint checks, and
  honest pack/transport/memory metrics.
- 2026-07-15: Started after T0383 implementation reached review. First slice will define and measure the minimal Snapshot-only compact package boundary; Linux benchmark evidence remains a later proof gate, not a reason to duplicate evaluator logic.
- 2026-07-15: Slice 1: added Snapshot-only items runtime package v1 builder plus strict Python reference inspector. The 504-byte vertical fixture uses fixed-width little-endian aligned sections, deduplicated strings, stable XXH64 item/schema/content fingerprints, flat item/field/level/value/cost rows, exact ownership coverage, and early row/byte budgets. Unsupported item capabilities fail instead of being silently dropped; C binding and generated ABI headers remain next.
- 2026-07-15: Quality: QTECH_001=pass; evidence: Runtime package review ACCEPT after canonical span ownership, full FIELD validation, fail-early budgets, and positive-cost fixes; package tests 5/5 including resigned corruption; all items-core 83/83 before final positive-cost guard plus targeted 5/5 after; studio verify --changed passed features domain; git diff check clean
- 2026-07-15: Slice 2: added structured build CLI, atomically write-if-different blob/header outputs, and an ABI header containing only schema/item/field identity. Value-only edits leave header bytes/mtime unchanged. Review fixes reject all input/output path overlap before writes, normalize argument/encoding failures to JSON, and publish the additive surface as items-core 1.8.0 with exact template/receipt pins.
- 2026-07-15: Quality: QTECH_001=pass; evidence: Slice 2 review ACCEPT; runtime package 8/8; items ops 29/29; all items-core 86/86; feature contracts pass; studio verify --changed passed features and template-release; git diff check clean
- 2026-07-15: Slice 3: added opt-in native package bind over the exact Python-generated fixture. Bind copies first, validates magic/version/generated item+field ABI/content digest/canonical layout/UTF-8/ranges/indices/spans/default 64 MiB gate, and publishes atomically only on success; rebind is refused, shutdown permits a later bind, and the lifecycle is explicitly main-thread serialized. Public resource acquisition remains next.
- 2026-07-15: Quality: QTECH_001=pass; evidence: Two independent native parser reviews ACCEPT after generated expectation, UTF-8, field-count, value-range, size-gate, dependency, and INT64_MIN fixes; Python items-core 86/86; warning-gated native test_items_runtime_package CTest 1/1; feature contracts pass; studio verify changed passed features/template-release; git diff check clean
- 2026-07-15: Slice 4: added the opt-in public resource-blob adapter. It maps missing/not-ready/wrong-type deterministically, checks stable asset type before readiness to avoid retrying a terminal mismatch, delegates ready bytes directly to the copying binder, and leaves pack placement/request timing game-owned. Review ACCEPT after the combined wrong-type+not-ready regression. Native runtime package/resource CTests 2/2, studio verify --changed passed features/template-release, and git diff check clean.
- 2026-07-15: Slice 5: moved the stable typed base item API behind either generated-C proof or runtime-package opt-in and implemented bound runtime lookups, exact hash-plus-string fallback, core copies, acquire transitions, opaque cost traversal, and debug labels over validated owned spans. Review fixes preserve authored free acquire in a validated item flag, bump accessor ABI, and keep the native fixture content hash canonical with a drift regression. Review ACCEPT; all items-core Python 87/87; warning-gated generated-C/runtime CTests 4/4; studio verify --changed passed features/template-release; git diff check clean.
- 2026-07-15: Slice 6: generated runtime capability structs and checked level accessors directly from Snapshot required_for fields while keeping values only in the blob. Weapon parity now covers kind probes, bounded level lookup, typed i64 copies, unavailable/cost/free transitions, and opaque level-cost copy-out. Review fixes make invalid capability refs return false/0 like generated-C and add one shared C-member guard at Snapshot/proof/runtime-header boundaries. Review ACCEPT; all items-core Python 87/87; warning-gated generated-C/runtime CTests 4/4; studio verify --changed passed features/template-release; git diff check clean.
- 2026-07-15: Added bounded Release benchmark for equivalent C-array and validated-blob candidates. Windows proof records equal typed-access checksum/run count, blob no-relink value edits, arrays winning tiny-fixture latency/section size, and honest non-RSS byte metrics; independent review accepted after Release/timer/metric/gate fixes. Linux current-branch benchmark remains required before closure; T0380 owns representative full-pipeline/RSS/budget ratification.
- 2026-07-15: Slice 7: added a read-only publication gate that regenerates expected blob/header solely from the current Snapshot and rejects stale selected pack inputs without a second manifest. Documented pack-owned placement plus catalog-before-state startup, exposed items-core 1.9.0, and synchronized canonical receipt/template pins. Review ACCEPT after fixing receipt-writer version drift; Items Python 89/89, feature contracts pass, studio verify --changed passed features/template-release, and git diff check clean.
- 2026-07-15: Local implementation complete and independently accepted. Review remains open only for the required Linux current-branch benchmark/CI proof; no local WSL, running Docker daemon, or authorized push is available.
- 2026-07-16: Ran the bounded Release benchmark in an isolated Python 3.12 Linux container with repository sources read-only and a separate build mount. `linux-2026-07-16.json` reproduces the Windows semantic checksum, 1,000,000 checked accesses, 568-byte blob, stable ABI header on value edits, and blob no-relink/C-array relink decision. Process RSS remains explicitly owned by T0380; runtime-entry identity remains E019 rather than a T0365 deliverable.
- 2026-07-16: Quality: QTECH_001=pass; evidence: Linux/Windows benchmark artifacts agree on semantic checksum and decision; benchmark contract 3/3; `node ai_studio/studio.mjs verify --changed` passed the features domain; artifact hash matches the isolated runner output.
- 2026-07-16: Closed after isolated Linux Release benchmark completed the final cross-platform proof gate.
- 2026-07-16: Quality: QTECH_001=pass; evidence: QTECH_001=Linux and Windows Release artifacts match semantic checksum and blob decision; benchmark contract 3/3; Studio verify --changed passed features
