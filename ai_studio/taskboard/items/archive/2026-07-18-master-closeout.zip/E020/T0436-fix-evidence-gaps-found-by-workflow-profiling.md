---
id: T0436
title: Fix evidence gaps found by workflow profiling
status: done
project: P001
epic: E020
priority: P1
tags: [profiling, workflow, ci, subagents]
created: 2026-07-15
updated: 2026-07-15
quality: {"checks":[{"id":"QTECH_001","outcome":"pass","evidence":"QTECH_001=profiling suite 33/33; harness domain pass; live transcript and agent rollup; full 10 domains"}]}
---

## What

Close two evidence gaps found by the canonical workflow profile: make an
explicit transcript path select only that source without an extra mode flag,
and make Codex subagent metrics discover exact thread-spawn children while
excluding internal guardian sessions.

## Done when

- [x] `status.mjs --transcript <path>` reads only that source without requiring `--complete`, and a missing path cannot fall back to another session.
- [x] Codex agent rollups discover the resolved `CODEX_THREAD_ID`, include only exact thread-spawn children, exclude internal guardians, and label the task honestly.
- [x] Focused profiling tests, changed verification, Quality review, and one final full verification pass.

## Open questions

- None; do not add a CI wrapper or new runner unless later measurements show a repeated need.

## Log

- 2026-07-15: Goal: correct profiler evidence and advice. Scope: `ai_studio/core_harness/profiling/` plus this task. Done: the three checkable behaviors above. Proof: RED/GREEN focused tests, `studio.mjs verify --changed`, QTECH review, and one `verify --full` before closeout.
- 2026-07-15: Baseline: Taskboard context 2,292 bytes; prior root transcript 2,712 measured tool results, 30 spawns, 233 waits (7.8/spawn), 29 normal spawn calls p50 11.2s, and `gh run watch` calls up to 73.4m. No current `taskboard/cli.mjs summary` references.
- 2026-07-15: Selected measured profiler evidence gaps for test-first fixes; no push and no new runner/cache.
- 2026-07-15: Implemented in `04f6fef2c`, `909f1cd62`, and `f460130f7`. Focused RED/GREEN covered each behavior; profiling suite passed 33/33 in 2.18s and harness owner-domain proof passed in 2.60s. Node/Python process snapshots showed zero new persistent PIDs after both gates.
- 2026-07-15: Quality: QTECH_001=pass; evidence: behavior-specific RED/GREEN tests, profiling suite 33/33, live explicit-transcript/agent-rollup output, harness domain pass, and zero new Node/Python PIDs after tests.
- 2026-07-15: Independent review rejected the first external-wait heuristic as incomplete complexity; reverted it in `8c63c4247`. Kept the two evidence fixes, added fail-closed transcript coverage in `7455844bd`, and proved the normal Desktop `--complete --agents` route with a focused integration test and live one-agent rollup.
- 2026-07-15: Final proof: `studio.mjs verify --changed` passed work-management in 5.19s; `studio.mjs verify --full` passed all 10 owner domains in 38.7s. No push performed.
- 2026-07-15: Independent re-review: ACCEPT after exact parent filtering and unrelated-parent regression coverage. Final harness owner-domain proof passed in 6.51s; external-wait advisory remains reverted.
- 2026-07-15: Quality: QTECH_001=pass; evidence: QTECH_001=profiling suite 33/33; harness domain pass; live transcript and agent rollup; full 10 domains
