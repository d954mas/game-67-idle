---
id: T0434
title: Review and groom remaining active Taskboard cards
status: done
project: P001
epic: E001
priority: P1
tags: [taskboard, cleanup, review]
created: 2026-07-14
updated: 2026-07-14
quality: {"notApplicable":{"reason":"Taskboard review and scope consolidation only; no product/runtime behavior changed"}}
---

## What

Review every remaining active Taskboard card against current repository evidence.
Keep actionable work, merge true duplicates, close completed or obsolete work,
and remove only records that carry no durable decision or future value.

## Done when

- [x] Every `review`, `backlog`, and `idea` card has a current disposition with evidence.
- [x] Duplicate or obsolete cards are merged or closed without losing unique decisions.
- [x] Epic scope and task dependencies match the retained work.
- [x] Taskboard validation passes and closed history is sealed out of normal search.

## Open questions

- Which review cards are already complete but lack closure evidence?
- Which large Items tasks overlap enough to merge without hiding distinct contracts?

## Log

- 2026-07-14: Started after sealed ZIP history rollout; current inventory is 4 review, 19 backlog, and 2 idea tasks across E009, E010, E016, and E019.
- 2026-07-14: Final dispositions after two independent read-only audits and lead integration:
  E009 keeps T0269/T0323; E010 closes T0222/T0225/T0255/T0336, returns T0258
  to backlog, and keeps T0266/T0317/T0326/T0331/T0432; E016 merges T0384 into
  T0383 and keeps the remaining authoring vertical; E019 keeps its four ordered
  runtime/state tasks. No retained card is a true duplicate or content-free
  record, so none was deleted merely to reduce the count.
- 2026-07-14: Retained task text was reduced where it repeated canonical
  contracts: T0365 now has eight measurable outcomes, T0323 owns only browser
  package smoke, and E016/T0366 are explicitly Items-owned.
- 2026-07-14: Validation passed; five closed/merged cards were sealed in
  `2026-07-14-taskboard-grooming-t0222-t0384.zip`, leaving no loose historical
  Markdown before this closeout task.
- 2026-07-14: Quality: not-applicable; reason: Taskboard review and scope consolidation only; no product/runtime behavior changed
