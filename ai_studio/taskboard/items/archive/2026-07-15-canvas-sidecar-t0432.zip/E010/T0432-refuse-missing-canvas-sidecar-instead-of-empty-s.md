---
id: T0432
title: Refuse missing Canvas sidecar instead of empty snapshot
status: done
project: P001
epic: E010
priority: P1
tags: [canvas, store, integrity]
created: 2026-07-14
updated: 2026-07-14
quality: {"checks":[{"id":"QTECH_001","outcome":"pass","evidence":"node --test ai_studio/assets/canvas/tests/sidecar.test.mjs ai_studio/assets/canvas/tests/local_cache.test.mjs: 12/12 pass"}]}
---

## What

Remove the remaining silent empty-snapshot fallback after the completed Canvas
store relocation. A missing/corrupt sidecar must fail with a stable diagnostic
or recover from an explicitly proven source; it must never publish `{}` as if
that were valid project state.

## Done when

- [x] `snapshotForEntry` cannot turn a missing sidecar into an empty project.
- [x] Recovery/refusal behavior has a focused regression test and stable error.
- [x] Existing local-cache migration and normal project reads remain green.

## Open questions

- Resolved: a thin journal contains metadata but no project state, so v1 refuses
  and requires the existing repair path.

## Log

- 2026-07-14: Split from T0259 during full Taskboard grooming. The relocation is
  complete; this card owns only the residual integrity risk.
- 2026-07-14: Selected for the current AI Studio cleanup pass after Canvas migration; scope remains missing/corrupt sidecar refusal plus focused regression coverage.
- 2026-07-14: Started TDD implementation: thin journals cannot reconstruct missing sidecar state, so v1 will refuse with a stable error and leave project/history unchanged.
- 2026-07-14: Implemented fail-loud missing/corrupt sidecar handling; project.json and journal remain byte-identical on refusal. Focused Canvas sidecar and local-cache suites pass 12/12.
- 2026-07-14: Quality: QTECH_001=pass; evidence: node --test ai_studio/assets/canvas/tests/sidecar.test.mjs ai_studio/assets/canvas/tests/local_cache.test.mjs: 12/12 pass
