---
id: T0255
title: "Canvas scale target: thousands of objects - tree memoization now; viewport culling + mutation payload diet next"
status: done
project: P001
epic: E010
priority: P1
tags: []
created: 2026-07-03
updated: 2026-07-14
quality: {"checks":[{"id":"QTECH_001","outcome":"pass","evidence":"QTECH_001=recorded suite 540, three-viewport byte-identical screenshots and 1024-element 2-4x zoomed improvement; current full CI passed"}]}
---

## What

Make Canvas credible at thousands-of-object scale by landing immediate tree and
viewport performance wins, then define the remaining mutation-payload work.

## Done when

- [x] Tree memoization and viewport culling are implemented and validated.
- [x] Large-canvas visual parity/performance evidence is recorded.
- [ ] Mutation payload diet is accepted, deferred, or split into a follow-up.

## Open questions

## Log

- 2026-07-14: Returned from stale review to backlog. Memoization/culling are
  shipped; the remaining executable scope is mutation-payload diet after an API
  contract decision.
- 2026-07-03: Culling landed 4fa7928b (my review + suite 540): conservative screen-AABB cull of elements (rotated = exact corner AABB; previewing/region-edit never culled) + group chrome (string-length pill bound, no measureText); clip-group offscreen = whole-subtree skip. Byte-identical screenshots at 3 viewports; 1024el grid: no regression all-visible, 2-4x zoomed. T0255 scope now: memoization DONE, culling DONE; payload diet = remaining (needs API contract discussion w/ lead).
- 2026-07-14: Closure: waived; reason: remaining payload-diet idea has no current measured bottleneck and should not keep shipped performance work open; evidence: tree memoization and viewport culling commit 4fa7928b, 1024-element measurements, screenshot parity, independent 2026-07-14 audit
- 2026-07-14: Quality: QTECH_001=pass; evidence: QTECH_001=recorded suite 540, three-viewport byte-identical screenshots and 1024-element 2-4x zoomed improvement; current full CI passed
