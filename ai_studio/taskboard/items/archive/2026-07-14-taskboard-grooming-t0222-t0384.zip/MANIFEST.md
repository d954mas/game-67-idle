# Sealed Taskboard history

Batch: 2026-07-14-taskboard-grooming-t0222-t0384
Tasks: 5

## Tasks

- T0222 | E010 | Canvas: text elements - Figma-like text node type (font, stroke, shadow)
- T0225 | E010 | Asset viewer: pretty previews regressed after gallery module move
- T0255 | E010 | Canvas scale target: thousands of objects - tree memoization now; viewport culling + mutation payload diet next
- T0336 | E010 | Alpha cutout всегда в копию + компактная кнопка Apply
- T0384 | E016 | Build requirements normalization and deterministic diagnostics
