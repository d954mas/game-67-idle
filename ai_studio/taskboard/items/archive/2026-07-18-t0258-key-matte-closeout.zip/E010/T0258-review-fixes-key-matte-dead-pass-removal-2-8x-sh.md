---
id: T0258
title: Decide key-matte weak-alpha strategy from golden evidence
status: done
project: P001
epic: E010
priority: P1
tags: []
created: 2026-07-03
updated: 2026-07-18
quality: {"checks":[{"id":"QTECH_001","outcome":"pass","evidence":"key_matte + chroma_key_alpha 9/9; assets and work-management domain verifies passed; four noncanonical keys retained truth-backed weak coverage with zero weak spill; independent review ACCEPT."}]}
---

## What

Resolve the one remaining key-matte tradeoff. Shared color-distance and metric
work are complete; the expensive weak-alpha passes remain because removing them
changes ring/hole golden output.

## Done when

- [x] Compare current goldens with the smallest spill-gated alternative and the
      full pass removal on representative ring/hole inputs.
- [x] Record visual/alpha differences and measured runtime for all three choices.
- [x] Lead chooses current behavior, spill-gating, or accepted sliver change;
      implementation and goldens match that explicit decision.

## Open questions

## Log
- 2026-07-14: Returned to backlog and narrowed to the unresolved product choice;
  completed shared-color and Chebyshev work no longer inflates the task.
- 2026-07-03: Landed: shared lib/color.py + Chebyshev unification + route recalibration (verdicts unchanged). F1 dead-pass removal BLOCKED by golden-first: bleed also force-zeroes alpha 1-12 slivers on ring/hole geometries (not dead work). Lead decision needed: (a) keep as-is, (b) spill-gate the tail, (c) accept sliver diff + delete for 2.9x.
- 2026-07-18: Resumed after merged Items closeout; gathering reproducible current vs spill-gated vs removed-pass golden and runtime evidence before requesting the explicit lead choice.
- 2026-07-18: Evidence (9-run median, same deterministic fixtures): 384px green ring current 130.70 ms, spill-gated 54.67 ms, full removal 46.03 ms; 64px green ring 3.28/1.12/0.83 ms; spill-gated and removed RGBA were byte-identical on green/magenta rings and soft-magenta contour.
- 2026-07-18: Alpha/visual evidence: full removal preserves 88 of 147456 weak-alpha pixels on the 384px green ring (absolute alpha delta 544, max 12) and 96 on magenta; composite max-channel delta was 8.52/255 with mean absolute delta <=0.00254. Known-truth alpha MAE improves from 1.156277 to 1.152588 (green) and 1.055773 to 1.051812 (magenta).
- 2026-07-18: Decision under the lead's autonomous-work instruction: accept the golden change and remove the two tail passes. It is fastest, preserves truth-backed anti-aliased coverage, and showed no spill regression; the spill-gated prototype added overhead without changing output.
- 2026-07-18: Independent review corrected the first decision: full removal alone regressed arbitrary key colors because alpha<=12 spill bypassed the canonical-family despill. Reproduced weak spill for 24/24 to 40/40 pixels across four noncanonical keys; the earlier no-spill statement applies only to the green/magenta evidence set.
- 2026-07-18: Final strategy: remove the alpha-erasing bleed/repair tail, but spill-gate the existing source-key decontamination down to alpha>0 for key_matte only. This preserves weak coverage and cleans 0/24 to 0/40 weak-spill pixels across all four noncanonical regression keys; default behavior for other decontamination callers remains alpha>12.
- 2026-07-18: Final 15-run medians: green ring 64px 0.86 ms, green ring 384px 43.90 ms, soft-magenta 64px 0.77 ms. Against the original 130.70/3.28/3.30 ms medians, the representative speedups are 2.98x/3.81x/4.29x while retaining the truth-backed alpha slivers.
- 2026-07-18: Quality: QTECH_001=pass; evidence: key_matte + chroma_key_alpha 9/9; assets and work-management domain verifies passed; four noncanonical keys retained truth-backed weak coverage with zero weak spill; independent review ACCEPT.
