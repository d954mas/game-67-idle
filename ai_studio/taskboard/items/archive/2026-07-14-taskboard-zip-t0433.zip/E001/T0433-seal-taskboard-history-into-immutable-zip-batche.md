---
id: T0433
title: Seal Taskboard history into immutable ZIP batches
status: done
project: P001
epic: E001
priority: P1
tags: []
created: 2026-07-14
updated: 2026-07-14
quality: {"checks":[{"id":"QTECH_001","outcome":"pass","evidence":"QTECH_001=73 Taskboard tests, 19 package tests, full Windows verify 10 domains, independent review"}]}
---

## What

Keep completed Taskboard history readable by humans without leaving full stale
Markdown in normal repository search. Periodically seal pending closed tasks
into immutable deterministic ZIP batches; do not add a growing global index.

## Done when

- [x] Closing remains guarded and writes readable Markdown to an ignored pending
      area until an explicit seal operation.
- [x] Sealing creates one deterministic immutable ZIP with original task files,
      verifies it before deleting sources, and refuses overwrite or partial loss.
- [x] Default Taskboard reads and ordinary `rg` do not discover sealed task
      bodies; explicit archive lookup extracts only the requested task.
- [x] Existing archived tasks are migrated into a verified sealed batch with no
      loose historical Markdown left behind.
- [x] Focused tests, Taskboard validation, full Windows verification, and
      independent review pass.

## Open questions

- None. Lead approved periodic immutable ZIP batches with direct human access
  and no global `index.jsonl`.

## Log

- 2026-07-14: Started from approved archive simplification. Scope is Taskboard
  history storage and lookup only; active tasks/projects/epics stay Markdown.
- 2026-07-14: Migrated 155 loose historical tasks into immutable
  `2026-07-14-studio-history-t0200-t0431.zip` (702921 bytes, SHA-256
  `3da346afa52ef2003e525206678e9e0add3e7ffe6efef4c57b03e512ce5aac8e`).
  Reopened lookup returns T0368 while default show and ordinary root `rg` do
  not find its body; loose archive Markdown count is zero.
- 2026-07-14: Final evidence: Taskboard 73/73, package ZIP 19/19, copied-template
  game/reporter tests pass, store validation and diff check pass, and full
  Windows verify passes all 10 domains in 29s. Independent re-review found no
  residual P0-P2 after atomic no-replace and symlink-confinement fixes.
- 2026-07-14: Quality: QTECH_001=pass; evidence: QTECH_001=73 Taskboard tests, 19 package tests, full Windows verify 10 domains, independent review
