---
id: T0269
title: "New game flow: create and link a per-game canvas project"
status: done
project: P001
epic: E009
priority: P2
tags: [games, canvas, template]
created: 2026-07-04
updated: 2026-07-18
quality: {"checks":[{"id":"QCLR_001","outcome":"pass","evidence":"real browser desktop/mobile owner filter, lifecycle labels, destination label, and keyboard/touch action flow verified"},{"id":"QTECH_001","outcome":"pass","evidence":"new-game 14/14 plus Canvas 781 and chat 95 suites green, architecture/taskboard validation green, independent review ACCEPT"}]}
---

## What

When a new game is created through the AI Studio new-game flow, create a
dedicated Canvas project for that game and write the canvas reference into the
game workspace so agents and the lead can open it later without manual setup.

## Done when

- [x] `games/new_game.mjs` (or the owning new-game workflow) creates a Canvas
      project for the new `games/<game-id>/` folder.
- [x] The created canvas is named and discoverable by game id/title, and the
      resulting `canvas://...` ref is stored under the game design docs.
- [x] Re-running or recovering a partially completed new-game flow does not
      create duplicate canvas projects when a canvas ref already exists.
- [x] The workflow output prints the canvas ref and browser URL alongside the
      game path.
- [x] Validation covers at least one dry-run or fixture path for a new game.
- [x] Canvas Home can filter by owner game and surface that game's active and
      archived projects without a second lifecycle card.

## Open questions

- Should the canvas start from a fixed per-game layout template, or only create
  an empty named project at this stage?

## Log

- 2026-07-14: Absorbed T0215 and T0334. Owner-game/archive backend support is
  already shipped; this task owns the remaining new-game link and compact Home
  discovery UI.

- 2026-07-04: captured from a prototype setup where its game canvas was created
  manually after the game, so future game creation should do this by default.
- 2026-07-18: Started from merged master after T0258 closeout; implementing the new-game Canvas link as an idempotent workflow slice with fixture coverage.
- 2026-07-18: Decision: create an empty, clearly named per-game Canvas now. A fixed layout template is deferred until a concrete reusable layout contract exists; this keeps new-game creation deterministic and avoids inventing premature structure.
- 2026-07-18: Implemented idempotent per-game Canvas creation/linking for public and private games, transactional recovery, owner/lifecycle Home discovery, store-confined creation, responsive layout, and keyboard/touch-accessible card actions. Tests: new-game 14/14, Canvas 781 (779 pass, 2 environment skips), Canvas chat 95/95; real Playwright desktop/mobile and keyboard focus-cycle smoke passed; independent review ACCEPT.
- 2026-07-18: Quality: QCLR_001=pass; QTECH_001=pass; evidence: QCLR_001=real browser desktop/mobile owner filter, lifecycle labels, destination label, and keyboard/touch action flow verified; QTECH_001=new-game 14/14 plus Canvas 781 and chat 95 suites green, architecture/taskboard validation green, independent review ACCEPT
