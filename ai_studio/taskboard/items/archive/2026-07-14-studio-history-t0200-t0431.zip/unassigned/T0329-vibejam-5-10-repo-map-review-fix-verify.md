---
id: T0329
title: "Ретро VibeJam: отложенные пп.5-10 (repo-map, review-fix-verify, профайлер, батчи, борда)"
status: done
project: P001
epic: ""
priority: P2
tags: [retro, pipeline]
created: 2026-07-06
updated: 2026-07-14
quality: {"notApplicable":{"reason":"planning and routing cleanup only"}}
---

## What

Отложенные пункты топ-10 плана ретро VibeJam (полный разбор:
tmp/session_profiles/reflection_vibejam_2026-07-06.md, раздел 11).
Формат разбора с лидом: проблема -> улучшение -> альтернативы -> вопросы,
по одному за раз. Пп.1-4 закрыты 2026-07-06 (DevAPI T0324, арт-гейт
T0317, стайл-лок T0326, "один писатель" -> фичевая архитектура T0327).

5. Repo-map артефакт в каждом пакете субагента (каждый агент заново
   изучал репо) - subagent-packet-template.
6. Постоянный контракт review->fix->verify вместо 6 ручных
   некумулятивных прогонов ревью (ночной COMBAT-цикл = рабочий шаблон).
7. Профайлер: слепой захват фейлов Codex, подписи PS-блоков, --all за
   период, rate_limits-фальшпозитивы, persistent cwd для Claude.
8. Батч-режимы горячих тулз (~100 мин ожиданий): canvas export,
   responsive_viewports, параллельный imagegen.
9. Универсальный редактор предметов - ПЕРЕЕХАЛ в T0316 (закрыт дизайном).
10. Гигиена борды: DoD-гейт, дедуп карточек, заполнить/закрыть стабы
    T0318/T0319/T0320.

## Done when

- [ ] Каждый пункт 5-8, 10 разобран с лидом (формат: проблема →
      улучшение → альтернативы → вопросы) и либо закрыт решением/задачей,
      либо осознанно отброшен.

## Open questions

## Log
- 2026-07-14: Closure: waived; reason: superseded during full Taskboard grooming without claiming new implementation; evidence: superseded by T0419 through T0431 and existing batch implementations
- 2026-07-14: Quality: not-applicable; reason: planning and routing cleanup only
