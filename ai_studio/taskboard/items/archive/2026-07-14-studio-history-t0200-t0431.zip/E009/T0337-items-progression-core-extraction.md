---
id: T0337
title: "Template: items-core + progression-core как игровые модули (features/, in-place)"
status: done
project: P001
epic: E009
priority: P1
tags: [template, architecture, features, modules]
created: 2026-07-07
updated: 2026-07-10
---

## What

Вынести инвариантные ядра items и progression из шаблона в корневой
`features/` как ИГРОВЫЕ МОДУЛИ, потребляемые in-place (прецедент =
`features/game-state`): одна копия исходников, каждая игра компилирует
их в своём билде против СВОИХ сгенерированных хедеров и конфигов.

Ратифицированная лидом (2026-07-07) трёхслойная модель:

1. Движок (`external/neotolis-engine`) — рендер/UI/платформа.
2. Игровые модули (`features/`, in-place) — переиспользуемая механика
   с конфигами: game-state (тулкит персистентности, уже там),
   items-core, progression-core.
3. Игра (`templates/template`, `games/<id>`) — конфиги (json) + тонкие
   C-хуки + композиция.

Швы (из разбора, лид согласен):
- items-core (инвариантно): items_containers.c (вся семантика
  владения), items_catalog.c, items.h, reconcile/seq-reseed из
  bootstrap, generate_items_catalog.py, items_ops.py (+тест), ядро
  Unity-тестов.
- items: игровая сторона: content/items.json + item_fields.schema.json
  + items.lock.json, state/items.schema.json (version + МИГРАЦИИ —
  всегда игровой код: шаг кодирует историю сейвов ЭТОЙ игры), посев
  on_new_game (сейчас 50 gold + 1 potion), reason_tags.h (закрытый
  список верб — свой у каждой игры; в ядро — через инклюд игрового
  файла по include-path или хук реестра).
- progression-core (режется чище): progression.c (режимы, T5-капы,
  ленивая аллокация) + generate_progression_tracks.py. Игре:
  progression.json + версия схемы/миграции. Посева нет by design,
  идл-доход в игровом demo_hud, вербы едут с items-вербами.
- Зависимость модулей: progression-core → items-core (L2→L1 на уровне
  модулей, слоёвость переживает вынос без изменений).
- settings и resource_panel — НЕ модули (UI-код, максимальное давление
  «перекрасить под себя»), остаются фичами-в-шаблоне под
  copy-then-own. resource_panel — кандидат в модули после двух игр без
  правок.
- Задняя дверь: игре с ДРУГОЙ семантикой владения разрешён форк ядра к
  себе (copy-then-own из модуля) — документировать.

Вместе с выносом (просьба лида): зафиксировать разделение
«модуль/фича/игровой код» там, где его будут искать:
- Доктрина трёх слоёв + решающее правило «когда модуль, когда фича,
  когда код игры» → корневой features/README.md (модель владения уже
  там, f99db5666) + src/features/README.md (конвенция).
- Тонкий скилл nt-game-feature (HOW-TO для агентов: создать/улучшить
  фичу или модуль; по образцу nt-game-items: README = WHAT, скилл =
  HOW-TO, не дублировать содержимое).

## Done when

- [x] features/items-core и features/progression-core существуют,
      шаблон собирает их in-place (CMake-пути), поведение
      байт-идентично до/после (G-relocation pure-rename + G-bytes
      генвыход + полный ctest зелёный + wasm-линк обоих пресетов +
      живой G-smoke; «SHA скринов» списан лидом 2026-07-08 — флейк
      по построению, см. Open questions п.3).
- [x] В шаблоне остались только игровые части (json-конфиги, lock,
      схемы стейта, посев, вербы, миграционный скелет) — грепом
      доказано отсутствие копий кода ядра.
- [x] Игровая сторона документирована: как игра добавляет предметы,
      треки, миграции, вербы БЕЗ правок модулей.
- [x] Доктрина трёх слоёв в обоих README + скилл nt-game-feature
      (синк .codex → .claude).
- [x] new_game.mjs-копия игры собирается против модулей из корня
      (пути переживают games/<id>-глубину).

## Open questions

Вопросы лиду из ревью спеки (2026-07-08, каждый = дефолт, ждёт
подтверждения лида; исполнение идёт по дефолтам):

- (1) Шов карточки «ядро Unity-тестов → items-core» ПЕРЕИНТЕРПРЕТИРОВАН:
  ни один Unity-.c сегодня не контент-агностичен (test_items_catalog.c
  ассертит tmpl.gold/6 демо-дефов) — это тесты ПОТРЕБИТЕЛЯ, остаются
  в шаблоне; в модуль едет только self-contained items_ops_test.py.
  Module-owned контент-агностичная фикстура уровня game-state/mini —
  инвестиция при второй игре. ПОДТВЕРЖДЕНО лидом 2026-07-08 («ок»).
- (2) Игровой уголок items остаётся src/features/items/ (reason_tags.h
  + посев + миграции). Дефолт вплетён в байт-идентичность: переезд в
  src/game_items/ сменил бы include-строку ВНУТРИ кода ядра — перенос
  перестал бы быть побайтным. Пере-решение ПОСЛЕ исполнения дороже.
  ПОДТВЕРЖДЕНО лидом 2026-07-08 («остаются в src/features/items/»).
- (3) «SHA скринов» из Done-when: гейт добавили и честно попробовали
  в М1 — флейк ПО ПОСТРОЕНИЮ (две капчи одного бинаря = разные SHA:
  идл-доход тикает реалтаймом, кадр недетерминирован). СПИСАН, замена
  = G-relocation (pure-rename git) + G-bytes (генвыход) + ctest +
  живой G-smoke (детерминированный, зелёный). Deep-ревью списание
  подтвердил. ПОДТВЕРЖДЕНО лидом 2026-07-08 («подтверждаю»).
- (4) Баннеры генераторов — жёсткие строковые литералы со старыми
  путями; мандат байт-идентичности ТРЕБУЕТ оставить их неверными в
  этой арке (починка = doc-only проход после, вне гейта G-bytes).
  ДЕФОЛТ: принято как техническое следствие, правится следом.

- Старт ПОСЛЕ коммита пакета гигиены T0327 (он трогает
  items_bootstrap/схему game — иначе конфликт). ВЫПОЛНЕНО: гигиена
  закоммичена d1a4ad0cc, арка стартовала.
- Имена папок: items-core/progression-core vs items/progression —
  дефолт items-core (отличать модуль от одноимённой игровой папки
  конфигов в шаблоне); решить в спеке.
- Где в шаблоне живут игровые C-хуки items (посев/вербы/миграции):
  остаётся папка src/features/items/ как «игровой уголок items» или
  переезд в src/game_items/ — решить в спеке.
- Риск (принят лидом): обобщаем на выборке из одной игры — первая
  реальная игра покажет, где швы прорезаны не там; ядро становится
  «почти движком», правки требуют дисциплины тестов (26+ юнитов едут
  с ядром).

## Log

- 2026-07-11: T0375 reconciliation: status and unchecked boxes were stale. Existing `features/items-core`, `features/progression-core`, root-module CMake wiring, the documented three-layer contract, `nt-game-feature`, and the recorded 16/16/new-game/wasm proof satisfy every criterion without new implementation.
- 2026-07-11: Quality: QTECH_001=pass; evidence: commits and verification gates already enumerated below, plus current tracked module/skill presence.

- 2026-07-07: создана по решению лида после арка-ревью T0327 и
  двухшагового разбора (items → progression аналогично; «по сути core
  для items или progression это игровые модули с конфигами» —
  подтверждено). Контекст-вилка: вариант А «указатели» (f99db5666)
  остаётся для фич; модули — это НЕ отказ от А, а перевод
  инвариантного ядра на прецедент game-state (in-place, без копий).
- 2026-07-08: АРКА ИСПОЛНЕНА ЦЕЛИКОМ (спека e2882641b, 2 Opus-ревью
  + 16 фиксов; каждый инкремент: исполнитель Sonnet → deep-ревью
  Opus → контроль → коммит).
  - М1 items-core 6da5d2e0f: pure-rename ×5 + разрез items_bootstrap
    побайтно (посев остался игровым, reconcile уехал);
    items_ops_test.py одна строка TEMPLATE_ROOT=parents[3].
  - М2 progression-core 40221fb91: pure-rename ×3; папка
    src/features/progression/ удалена целиком (C-уголка нет by
    design); deep-ревью ACCEPT чистый.
  - М3 475e511ec: доктрина категорий + решающее правило + задняя
    дверь в features/README.md; конвенция в src/features/README.md;
    аудит stale-путей items README + nt-game-items (оба); НОВЫЙ скилл
    nt-game-feature; G-newgame проба t0337-probe (модули компилируются
    из КОРНЯ из games/<id>, ctest 16/16, wasm линк, new_game.mjs без
    правок — депт-2 инвариант доказан; следы вычищены). Deep-ревью
    ACCEPT без фикс-листа.
  - Гейты арки: ctest 16/16 оба пресета; G-bytes генвыход
    байт-идентичен (4 пресета); G-relocation pure-rename 100%;
    wasm оба пресета; G-smoke; G-copies/G-noleak/G-inc/G-rev;
    G-doctrine (skills_sync --check exit 0 — буквальный diff-гейт
    невыполним: .claude-скиллы = генерённые стабы, замена
    задокументирована); G-newgame.
  - Отклонения (легитимность подтверждена deep-ревью): id пробы
    t0337-probe (regex new_game.mjs запрещает «_»); синк скиллов
    через skills_sync.mjs вместо побайтного diff.
  - ХВОСТЫ (вне арки): doc-only проход по баннерам генераторов
    (+ докстринг items_ops.py:9-11 «py -3.12 tools/…» — та же цена
    байт-идентичности); док-синк витрины README.md/TEMPLATE.md +
    интеграционный ctest — хвост T0327. Done-when все 5 функционально
    закрыты (оценка deep-ревью М3) — чекбоксы и закрытие за лидом.
- 2026-07-11: T0375 status reconciliation: done; log records the complete M1-M3 arc and current module/skill paths plus 16/16/new-game/wasm proof satisfy all criteria.
