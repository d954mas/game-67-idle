---
id: T0327
title: "Template: feature-based architecture (src/features, слои, per-feature state/assets)"
status: done
project: P001
epic: E009
priority: P1
tags: [template, architecture, features]
created: 2026-07-06
updated: 2026-07-10
---

## What

Перевести templates/template на фичевую архитектуру, принятую лидом
2026-07-06. Текущий контракт категорий и ownership: `features/README.md`.

Ключевые решения (лид, 2026-07-06):
- Игра = набор фич; фича = папка src/features/<id>/ (код + ассеты + стейт +
  тесты), один публичный хедер, остальное static.
- Слои строго вниз: L0 шелл → L1 foundation (items/inventory/wallet) →
  L2 surface (shop/combat/...). L2→L2 запрещено — опускаем зависимую-от вниз.
- Кадр = явный агрегатор game_features.c (список = z-order), БЕЗ hook-таблиц.
- Вызов показа экрана — задача игры; bottom_nav = фича-виджет (entries от
  игры), фичи в нав не саморегистрируются.
- Стейт: map по фичам в сейв-документе (ключ = id фичи), типизированные
  структуры в рантайме; числовые id-диапазоны отменены.
- Ассеты: в игре — общий assets/ с тегом feature=<id> в assets.jsonl; в
  библиотеке features/<id>/assets/ самодостаточно; у фичи свой атлас-блок
  через <id>_pack_assets(ctx).
- Copy-then-own; обобщаемые улучшения промоутить в features/ до закрытия игры.

Инкременты (каждый shippable):
1. src/features/ + game_features.{c,h} + settings как первая фича
   (перенос sys_settings, main.c-кадр сворачивается; поведение идентично).
2. src/features/README.md — конвенция (слои, one-public-header, фазовый
   контракт, no-World-fields, стейт/ассет-правила).
3. Per-feature стейт в сейв-документе (под-объект на фичу; save/load хуки
   руками через game_storage; генератор — только по факту боли).
4. bottom_nav как фича-виджет + ассет-шов в build_packs.c.
5. Item-система как обучающий набор (текущий контракт:
   `features/items-core/README.md`, прошёл адверсариальное ревью):
   ОДНА фича items = каталог (ядро+блоки equip/use/currency) + стаки int64
   + пул инстансов + контейнеры (слияние по ревью, лид подтвердил;
   инвариант «инстанс ровно в одном контейнере» в одном месте; purse =
   скрытый контейнер валют/опыта). Вместе с фичей: op-слой
   (list/validate/upsert/deprecate/icon-link/schema) + CLI + скилл
   nt-game-items (tool parity; T0316 = только веб-клиент поверх).
   Учебная L2-фича сверху: progression (лид принял 2026-07-06) — треки
   {id, currency_def, кривая, max, режим manual|auto|threshold}, опыт =
   currency-предметы в purse, трек-стейт = level; + HUD-бейдж.
   shop НЕ в шаблоне (при первой реальной игре).
   equipment (слоты-как-данные) — при первой игре с экипировкой.
6. (отложено до первого промоута во 2-ю игру) extraction-тулинг:
   schema-фрагменты в генераторе, feature.json→INSTALL, extract-feature
   для ассетов; расширение features/README чеклистом.

## Done when

- [x] И1 (settings-эталон + README-конвенция) в templates/template: сборка
      native+web зелёная, поведение идентично (settings работает через
      game_features, sys_settings умер, папочная конвенция src/features/<id>/).
      ФАКТ 2026-07-07 (027d7c212): гейты G1-G8 зелёные — ctest 9/9, smoke_bot
      8/8 + живой смоук (settings/gear в ui.tree, master_volume в schema/get),
      wasm-release и wasm-devapi-debug линкуются, FEATURE_GAME_STATE=OFF
      линкуется под -Werror, скрин панели идентичен, grep: ноль sys_settings
      в шаблоне; спека → 2 ревью (ACCEPT-WITH-FIXES/ACCEPT) → фикс-раунд →
      исполнитель → deep-ревью ACCEPT-WITH-ADDITIONS (док-дрейф INSTALL.md/
      TEMPLATE.md закрыт в том же коммите).
- [x] И2 items + И3 progression+resource_panel в шаблоне собираются,
      слоёвое правило видно в коде (progression включает items.h,
      обратного нет); золото/опыт живут как currency-предметы в purse;
      resource_panel не инклюдит ни items.h, ни progression.h (entries
      с геттерами от игры).
      ФАКТ 2026-07-07: И2 четырьмя коммитами (см. Log) + хвост
      9b911bdbe; И3a 5c784f8b3; И3b закоммичен следом (resource_panel
      L2 generic + game_format L0 + demo_hud композиция игры). Грепы
      слоёвости в обе стороны чисты (deep-ревью подтвердило: панель —
      только self+engine+game_format), ctest 16/16, wasm линкуется,
      скрины: панель читается, модалка settings не пробивается.
- [x] features/README.md обновлён полями layer/provides/registers/assets_tag/
      art_needs в feature.json-контракте (декларативная арт-модель).
      ФАКТ 2026-07-07: отгружено в И1 (027d7c212); первый реальный
      feature.json с art_needs — resource_panel (И3b).
- [x] Дизайн-док перенесён из tmp/ в постоянное место.

## Open questions

- Ревью 4× завершены; принятые решения сохранены в текущих owner-contracts.
  Перед реализацией: (а) doc-sync по принятому чек-листу (доки
  противоречат — агенту не отдавать), (б) implementation spec инкремента 1,
  (в) T0328 (state toolkit) — S2/S4 предшествуют стейт-части items.
  LEAN-порезы инкремента 1: события, level_down→set_level/reset, хвост,
  bake, Diablo-статы, сетка, широкий op-слой, shop-стаб.

РЕШЕНО лидом 2026-07-07 (старт арки):
- Предпосылки сняты: doc-sync сделан (4238ab89), T0328 закрыт целиком
  (A0-A6, E1-E4). Карта разрыва: инкр.1 частично / инкр.3 полностью
  поглощены T0328 (game_features 7 фаз, settings-фрагмент, реестр
  фрагментов с on_new_game); инкр.2/4/5 были открыты.
- Shop: ВНЕ шаблона («магазин слишком специфичен для игры») —
  противоречие What/Done-when решено в пользу What, Done-when поправлен;
  слоёвость доказывает progression.
- bottom_nav-виджет ВЫРЕЗАН («просто набор кнопок»): кода не будет;
  правило навигации (фичи экспортируют open/close/is_open, состав нава =
  код игры, саморегистрации нет) → README-конвенция. Форма нава — при
  первой реальной игре.
- Ассет-шов <id>_pack_assets УМЕР, заменён декларативной моделью: фичи
  никогда не пишут в паки; feature.json art_needs {slot, kind, hint} +
  README-рецепт; example-ассеты в библиотечной копии
  features/<id>/assets/ (с provenance); конкретные хендлы фича получает
  от игры как конфиг; graceful-фолбэк без арта; build_packs.c остаётся
  100% игровым. Кастомизация тремя ступенями: конфиг → правка копии
  (поведение) → промоут обобщаемого в features/.
- HUD-бейдж ЗАМЕНЁН generic-фичей resource_panel (золото/опыт/премиум-
  валюта/…): entries {id, icon-хендл, label, getter} от игры, две
  визформы (счётчик + прогресс-бар), displayed≠logical, count-up
  (ease-out, ретаргет, снап на больших дельтах), акцент цвет/punch,
  poll+diff внутри виджета (коалесит идл-спам, не занимает event-лог),
  стейт только транзиентный, int64-abbrev форматтер общим хелпером.
  Демо шаблона: золото (счётчик) + xp-бар с уровнем. Floater ±N и полёт
  монет — ОТЛОЖЕНЫ в будущую отдельную фичу coin_fx; звук не нужен
  (решение лида). Шов под полёт закладывается сразу и стоит один
  аксессор: resource_panel_anchor(entry_id) в публичном API. Ресёрч:
  индустрия (displayed/logical, коалесинг, K/M/B) + анти-уроки
  rb-dark HUD (хардкод порогов уровней, reach в god-struct, int32 без
  анимации; забрать хорошее: shadowed_label, бары track+fill).
- Порядок остатка: И1 settings-эталон (папка src/features/settings/,
  UI из sys_settings въезжает, main.c чистится от прямых sys_*-вызовов)
  + README-конвенция + поля feature.json-контракта → И2 items →
  И3 progression + resource_panel. Каждый инкремент через полный процесс
  (спека → 2 ревью → исполнитель → deep-ревью → контрольный прогон →
  коммит).
- И2 (2026-07-07): лид ратифицировал OQ1 — `content/` = стандартная
  папка контент-данных И в шаблоне, И в играх (items.json туда;
  компайл-тайм embed, не рантайм-парс). Дефолты (порядок
  settings→items→game; CLI на Python; карантин = флаг на записи) —
  без возражений лида.
- И2 (2026-07-07, ПЕРЕ-РЕШЕНИЕ OQ4): «игра без стейта невозможна» —
  ось FEATURE_GAME_STATE УБИТА ЦЕЛИКОМ. Стейт-система всегда включена:
  CMake-опция и все #if/#else в шаблоне удаляются (settings теряет
  вторую версию, main.c-гейты умирают), items и все будущие фичи
  пишутся в ОДНОЙ версии, гейт «собирается без стейта» отменён.
  Снимает H2 дизайн-ревью и H1 код-ревью И2-спеки по построению.
- Карантин (лид 2026-07-07): карантинная запись ЗАНИМАЕТ слот
  вместимости контейнера (переполнения при оживлении не бывает по
  построению); намеренное удаление отгруженного def = шаг миграции
  (удалить / конвертировать в компенсацию); визуал для будущих
  инвентарных UI — серая заглушка «?» (финальное решение при первой
  игре с инвентарём).
- Деструктивные правки каталога (лид 2026-07-07): удаление/
  переименование отгруженного def ПРИНУДИТЕЛЬНО требует реакции —
  items.lock.json v2 с секцией removed {def_id: {fragment_version}};
  validate требует квитанцию + подъём версии фрагмента, а генератор
  (version == миграции+1) физически требует шаг миграции (настоящий
  или явно-пустой = осознанный карантин). Батч: N удалений = одна
  версия = один шаг. note опциональна. Забыл любой из шагов — красный
  validate или красная сборка с точным указанием, чего не хватает.

## Log

- 2026-07-11: T0375 reconciliation: the remaining doc criterion is satisfied by tracked `features/README.md`; prior implementation and verification evidence remains authoritative.
- 2026-07-11: Quality: QTECH_001=pass; evidence: recorded native/web builds, ctest, smoke, layering checks, and permanent design document.

- 2026-07-06: создана по решению лида после двух-угольного Opus-дизайна
  (bottom-up от кода rb-dark-rpg + top-down от целей студии) и правок лида
  (нав = задача игры; стейт = map по фичам). Контекст: коллизии параллельных
  агентов на общих файлах в VibeJam (game_actions.c 1769 строк, bottom_nav
  switch), пункт 4 плана ретро закрыт архитектурой вместо процессных правил.
- 2026-07-07: старт арки, status=doing. Карта разрыва снята (Explore),
  решения лида зафиксированы (см. Open questions: shop вне шаблона,
  bottom_nav вырезан, декларативная арт-модель, resource_panel вместо
  HUD-бейджа). Ресёрч плашки ресурсов выполнен (Opus: индустрия +
  rb-dark). Спека И1 запущена.
- 2026-07-07: И2 ГОТОВ ЦЕЛИКОМ, четырьмя коммитами: И2-0 759326967
  (ось FEATURE_GAME_STATE убита, байт-идентичность SHA256), И2a
  8df1c80bb (content/items.json + первый контент-codegen + скелет
  фрагмента, ctest 11/11), И2b f0381b038 (владение/purse/Р9-хуки/
  карантин; deep-ревью поймал 5 data-loss багов ДО коммита — seq-reseed
  уников, int64-overflow, self-move, clamp-conservation, capacity
  уник-move; 26 Unity-тестов), И2c 91b6eefc5 (CLI items_ops list/
  validate/schema --json + lock v2 c деструктивным гардом + README
  фичи + скилл nt-game-items). Каждый срез: исполнитель → deep-ревью →
  фикс-раунд → контрольный прогон. ОСТАЛОСЬ: И3 progression +
  resource_panel (спека дальше).
- 2026-07-07 (ночь): пакет гигиены ГОТОВ, d1a4ad0cc. Схема game
  выпотрошена от rb-dark модели (грепом доказано: НИ ОДНО поле не было
  живым — hero/battle/quest/old_mine/wallet/items-map/inventory/
  equipment мертвы, items/progression владеют этой землёй фрагментами;
  v1 без миграции, демо-поля + tutorial.done оставлены). Hold to reset
  progress = новая игра В СЕССИИ: pending-механика (request из draw_ui
  → apply в начале следующего update; выбрано исполнителем осознанно —
  прямой вызов из draw_ui делал бы файловый I/O + items.txn внутри
  живого render pass), skip «settings» (громкости уцелевают), форс-сейв
  сразу. --fresh-state неявно отключает автосейв (иначе дебаунс затирал
  бы реальный сейв). Живое доказательство reset через devapi: gold=50,
  potion=1, tracks={}, master_volume нетронут, autosave перезаписан
  (tmp/t0327_hygiene/). Коллатерал: голдены features/game-state
  перегенерированы (сьют лочит codegen схемы шаблона побайтно).
  Гейты: ctest 16/16, pytest 44/44, смоук, wasm-release. НАХОДКА для
  лида: «keep»-поля (shape_index/render_mode/camera_distance/
  test_label/test_button) тоже не читаются игровым кодом — живут только
  как демо-поверхность схемы/DevAPI/codegen; решить судьбу отдельно.
  ОСТАЛОСЬ в арке: док-синк витрины + интеграционный ctest на 4
  фрагментах (отдельный раунд).
- 2026-07-07 (вечер): арка-ревью собранного целого (2 независимых
  Opus: архитектура/конвенция + сквозной код-аудит). Вердикты: цель
  достигнута, сквозных data-loss/UB НЕТ. Находки: [M] легаси
  rb-dark поля в game-фрагменте (двойная модель героя/золота); [M]
  витринные README.md/TEMPLATE.md не знают о фичевой модели; [M] нет
  интеграционного ctest на 4 реальных фрагментах; [L] --fresh-state
  затирает автосейв; Hold to reset сбрасывает только позицию игрока
  (лид споткнулся на живой приёмке; золото 0 у лида = старый сейв,
  ретро-посева нет by design — корректно). РЕШЕНИЯ ЛИДА: (1) пакет
  гигиены — потрошим game-фрагмент до демо-стейта, Hold to reset →
  сброс прогресса (новая игра в сессии + форс-сейв), fresh-state
  неявно отключает автосейв; (2) промоут: сначала «снапшот-копии в
  features/», затем лид ПЕРЕ-РЕШИЛ → вариант А «указатели» (совпал
  с рекомендацией ревью): features/README.md = каталог с путями в
  шаблон + модель владения (истина одна = шаблон, копий нет; триггер
  настоящего промоута = второй шаблон / расхождение потребителей) —
  ЗАКОММИЧЕНО f99db5666. Пакет гигиены у исполнителя (Sonnet).
  Дальше: док-синк витрины + интеграционный тест отдельным раундом.
- 2026-07-07: И3b ГОТОВ — АРКА КОДА ЗАВЕРШЕНА. resource_panel (L2
  generic-виджет: entries+getter от игры, counter+bar,
  displayed≠logical, count-up ease-out/ретаргет/снап, punch в
  фикс-ячейке, poll+diff, transient-only, graceful no-art, anchor
  best-effort, НОЛЬ фича-хедеров) + game_format (L0 int64-abbrev,
  INT64_MIN-safe) + demo_hud (композиция игры: золото-счётчик +
  xp-бар, idle-доход loot:demo_idle). Deep-ревью: ACCEPT-WITH-FIXES —
  z-order фикс (zIndex=-1: текст панели протекал бы поверх модалки
  settings), UB-негация в rp_i64_abs, poll-once max(); визуальная
  находка оркестратора: наезд панели на демо-титул — титул уехал вниз
  (src/ui/hud.c). ctest 16/16, wasm, грепы чисты, 2 скрина одобрены.
  Принятые решения теперь принадлежат текущим feature owner-contracts.
  Осталось лиду: приёмка глазами (count-up в
  движении не headless-гейтится) + закрытие карточки.
- 2026-07-07: И3 спека 962f771de (2 Opus-ревью ACCEPT-WITH-FIXES →
  19 фиксов + LEAN: on_level_up codegen-ветка вырезана, кривые
  exp-only + обязательный golden запекания, progression.json БЕЗ
  created/lock — решение записано в спеку). И3a ГОТОВ: progression
  (L2) — треки-данные + codegen кривой FLOOR→int64, xp из purse
  (включает items.h — единственное фича-ребро), T5-капы (64/8,
  анти-хэнг доказан), 4-й фрагмент settings→items→progression→game,
  событие levelup (old/new честные, только из тика). Deep-ревью
  поймал data-loss ДО коммита (manual level_up списывал purse до
  аллокации трек-записи — при 32/32 валюта сгорала) + гард усечения
  ключа по §2.1; 7 фиксов + 3 новых loud-reject генератора. ctest
  15/15, wasm оба пресета, грепы слоёвости чисты. ОСТАЛОСЬ: И3b
  (resource_panel + game_format + demo_hud).
- 2026-07-07: И2c фикс-раунд (ревью гарда) + разворот лида по дате:
  гард стал ОБЯЗАТЕЛЬНЫМ (items_ops validate + items_ops_test в ctest,
  13/13), new_game.mjs сбрасывает lock новой игры в пустой baseline
  (copy-then-own: шаблонные 6 демо-defs не наследуются как «отгруженные»),
  битая форма lock = exit 2 (не тихое отключение гарда); поле `created`
  (ISO-дата) обязательно в items.json (git-лог ненадёжен — copy-then-own
  обнуляет историю), правила created-missing/created-invalid, в C-таблицы
  не эмитится.
- 2026-07-07: И1 ГОТОВ (027d7c212). settings = эталонная фича-папка,
  main.c чист от прямых UI-вызовов, game_features_draw_ui владеет
  ui_runtime-кадром, README-конвенция отгружена (слои с persistence
  toolkit=L0, навигационное правило, арт-модель art_needs, лестница
  кастомизации), контракт feature.json в корневом features/README
  (layer/provides/registers/assets_tag/art_needs). Полный процесс:
  спека → 2 Opus-ревью → фикс-раунд (11 пунктов) → исполнитель (Sonnet)
  → deep-ревью → контрольный прогон. ДАЛЬШЕ: И2 items (спека).
- 2026-07-08: ХВОСТ АРКИ ЗАКРЫТ — оба [M] арка-ревью сняты тремя
  коммитами (мини-спека fdbd66428: 2 Opus-ревью → 9 фиксов; после
  T0337 — ядра уже в модулях):
  - 914b9c22c кодировка: TEMPLATE.md был UTF-8, прочитанным как
    CP1251 и пересохранённым (35 глифов: em-dash/→/×/✕);
    восстановлено CP1251-раундтрипом, diff только в глифах;
    + 2 строки assets/ui/README.md (находка deep-ревью).
  - 380f7e3d4 витрина: README.md/TEMPLATE.md синхронизированы с
    фактическим деревом — файлы-фантомы удалены (греп-гейт пуст),
    Reuse tiers честен про linked-shared = движок + in-place модули
    (указатель на features/README §Categories, без пересказа),
    Startup UX = живой HUD, тестовая база 17.
  - 1890a8baf test_template_composition (ctest 16→17 оба пресета):
    первый тест композиции ВСЕХ 4 реальных фрагментов — реестр по
    порядку (осознанный контракт: count==4, новый фрагмент обновляет
    тест), посев new_game поперёк фрагментов, save→load через
    реальный конверт поперёк ребра L2→L1, hold-to-reset skip
    settings. Отклонения (легитимность подтверждена deep-ревью):
    nt_ui_interface header-only в линк (settings.c впервые вне
    game-таргета, движковый #error NT_UI_DEBUG_TOOLS); reason-строки
    cheat:* (закрытый список верб отверг спековые test:*).
  - Deep-ревью реализации: ACCEPT, гейты воспроизведены независимо
    (ctest 17/17 ×2, pytest 41, греп-гейт). Ноты вне скоупа: спека
    §4 называет pytest-базу 44 (фактическая 41 — док-нит истории);
    финальный прогон после коммитов 17/17. Карточку закрывает лид
    (приёмка count-up глазами уже сделана).
- 2026-07-11: T0375 status reconciliation: done; the last doc criterion exists in `features/README.md` and prior native/web/ctest evidence proves implementation.
