---
id: T0262
title: "Video generation speedup: research + rank options (TeaCache/Sage/steps/resolution ladder/faster engines), then apply best to WAN stack"
status: done
project: P001
epic: E010
priority: P1
tags: [video, perf]
created: 2026-07-03
updated: 2026-07-14
quality: {"checks":[{"id":"QTECH_001","outcome":"pass","evidence":"QTECH_001=preserved speed research and profiles used by the T0265 video flow, full Studio CI run 29329533678 green"}]}
---

## What

Research and apply video-generation speedups for the WAN stack, separating real
accelerators from quality-risk shortcuts.

## Done when

- [x] Speedup research ranks TeaCache/Sage/step/resolution options.
- [x] Current WAN baseline is re-measured and draft/final profiles are recorded.
- [ ] Chosen speed profile is carried into the next pipeline/card task.

## Open questions

## Log
- 2026-07-03: Research DONE (tmp/research_T0262_speedup_2026-07-05.md). Key: TeaCache/MagCache WRONG TOOL on already-distilled 4-8 step stack (assumptions break, motion stutter); SageAttention is the one worthwhile accelerator (1.15-1.4x). Package 1 ZERO-INSTALL draft profile: 384px + 25 frames + 4 total steps + batch seeds -> projected warm 35-57s (vs 103s). Package 2: + SageAttention on a COPY of portable -> 30-50s. Draft->final ladder = SAME engine locked seed (cross-engine draft defeats prediction). APPLY step queued until T0261 frees the experiment folder/GPU; must first confirm actual current step count (4 vs 8).
- 2026-07-03: APPLY DONE: baseline was ALREADY 4 steps (research q answered); honest re-baseline: real multi-run warm 480/33 = ~54s (103s was shallow-warm w/ partial disk read). Draft 384/25 = ~35.5s steady (x2 seeds), final 54s, peak VRAM 10.4/12.3GB. Draft quality ACCEPT (flap readable, no photoreal collapse); ladder correspondence STRONG (same seed draft->final, codex-vision judged). Edit loop: ~35s/motion-try, explore 4 seeds + ship one ~3min. Finding: high/low split timing-NEUTRAL at 4 steps (swap happens once regardless) - quality knob not speed knob. Files: draft/final_workflow_api.json + README profiles section.
- 2026-07-14: Closure: waived; reason: grooming reconciled a stale historical checklist with the delivered or retained scope; evidence: preserved speed research and profiles used by the T0265 video flow
- 2026-07-14: Quality: QTECH_001=pass; evidence: QTECH_001=preserved speed research and profiles used by the T0265 video flow, full Studio CI run 29329533678 green
